package com.example.gweiland_app_task;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    AdapterClass adapter;

    RecyclerView recyclerViewObject;
    ArrayList<ModelClass> taskData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        taskData = new ArrayList<>();
        recyclerViewObject = findViewById(R.id.recycler_view_id1);
        taskData.add(new ModelClass("ETH","Ethereum","$3,800 USD","-3.2%",R.drawable.ethicon));
        taskData.add(new ModelClass("BNB","Binance Coin","$450 USD","+1.8%",R.drawable.binance_coin_cryptocurrency_logo));
        taskData.add(new ModelClass("ADA","Cardano","$450 USD","-2.7%",R.drawable.ada__1_));
        taskData.add(new ModelClass("XRP","Ripple","$1.20 USD","+1.5%",R.drawable.xrp__1_));
        taskData.add(new ModelClass("SOL","Solana","$155 USD","-4.1%",R.drawable.sol__1_));
       // taskData.add(new ModelClass("ETH","Ethereum","$3,800 USD","-3.2%",R.drawable.ethicon));


        adapter = new AdapterClass(taskData);
        adapter.notifyDataSetChanged();
        recyclerViewObject.setAdapter(adapter);
        recyclerViewObject.setLayoutManager(new LinearLayoutManager(this));
    }
}