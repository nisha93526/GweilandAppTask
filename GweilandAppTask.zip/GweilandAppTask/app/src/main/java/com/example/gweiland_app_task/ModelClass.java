package com.example.gweiland_app_task;

public class ModelClass {
    String currencyFullName,currencyShortName,currencyPrice,currencyStatus;
    int currencyLogo;

    public String getCurrencyFullName() {
        return currencyFullName;
    }

    public String getCurrencyShortName() {
        return currencyShortName;
    }

    public String getCurrencyPrice() {
        return currencyPrice;
    }

    public String getCurrencyStatus() {
        return currencyStatus;
    }

    public int getCurrencyLogo() {
        return currencyLogo;
    }

    public ModelClass(String currencyFullName, String currencyShortName, String currencyPrice, String currencyStatus, int currencyLogo) {
        this.currencyFullName = currencyFullName;
        this.currencyShortName = currencyShortName;
        this.currencyPrice = currencyPrice;
        this.currencyStatus = currencyStatus;
        this.currencyLogo = currencyLogo;
    }
}
