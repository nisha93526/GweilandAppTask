package com.example.gweiland_app_task;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class AdapterClass extends RecyclerView.Adapter<AdapterClass.ViewHolderClass>
{

    ArrayList<ModelClass> taskData;

    public AdapterClass(ArrayList<ModelClass> taskData) {
        this.taskData = taskData;
    }


    //interface

    @NonNull
    @Override
    public ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolderClass(LayoutInflater.from(parent.getContext()).inflate(R.layout.single_currency, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderClass holder,int position) {
        holder.cprice.setText(taskData.get(position).getCurrencyPrice());
        holder.cname.setText(taskData.get(position).getCurrencyShortName());
        holder.ctitle.setText(taskData.get(position).getCurrencyFullName());
        holder.cstatus.setText(taskData.get(position).getCurrencyStatus());
        holder.clogo.setImageResource(taskData.get(position).getCurrencyLogo());
    }
    @Override
    public int getItemCount() {
        return taskData.size();
    }

    public static class ViewHolderClass extends RecyclerView.ViewHolder {
        TextView ctitle,cname,cprice,cstatus;
        CardView cardView;

        ImageView clogo;

        public ViewHolderClass(@NonNull View itemView) {
            super(itemView);

            cardView=itemView.findViewById(R.id.cardView);
            ctitle=itemView.findViewById(R.id.ctitle);
            cname=itemView.findViewById(R.id.cname);
            cprice=itemView.findViewById(R.id.cprice);
            cstatus=itemView.findViewById(R.id.cstatus);
            clogo=itemView.findViewById(R.id.clogo);
        }
    }
}
